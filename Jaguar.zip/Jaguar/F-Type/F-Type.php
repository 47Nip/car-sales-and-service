<!DOCTYPE html>
<html>
<head>
  <title>CAR DAETAILS</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    /* CSS styles for the car details page */
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    
    .car-images {
      display: flex;
      justify-content: space-around;
      align-items: center;
      height: 400px;
      background-color: #f2f2f2;
      gap: 20px; /* Adjust gap between images */
    }
    
    .car-images div {
      width: 25%; /* Set width of each image container */
      text-align: center; /* Center align text */
    }

    .car-images img {
      width: 100%; /* Set width of each image */
      height: auto; /* Maintain aspect ratio */
      border-radius: 5px; /* Add border radius for rounded corners */
    }

    .car-images p {
      margin-top: 5px; /* Adjust spacing between image and text */
      color: #333; /* Set color of the text */
      font-size: 16px; /* Set font size of the text */
      font-family: Arial, sans-serif; /* Set font family of the text */
    }
    
    
    .car-name {
      text-align: center;
      font-size: 24px;
      margin: 20px 0;
    }
    
    .car-details {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      grid-gap: 20px;
      padding: 20px;
    }
    
    .car-details-block {
      background-color: #f2f2f2;
      padding: 20px;
      border-radius: 5px;
    }
    .mileage-details {
      padding: 20px;
      background-color: #f2f2f2;
      border-radius: 5px;
    }
    
    .mileage-details__heading {
      font-size: 24px;
      text-align: center;
    }
    
    .mileage-details__table {
      list-style: none;
      padding: 0;
    }
    
    .mileage-details__table li {
      display: flex;
      justify-content: space-between;
      margin-bottom: 10px;
    }
    
    .mileage-details__table li span {
      font-size: 18px;
    }
    
    .mileage-details__value {
      font-weight: bold;
    }
    
    /* Styling for the "Get a Caller from Dealer" section */
    .get-caller-option {
      background-color: #f9f9f9;
      padding: 20px;
      border-radius: 5px;
      margin-top: 20px;
    }
    
    .get-caller-option h2 {
      font-size: 24px;
      text-align: center;
    }
    
    .get-caller-form {
      display: flex;
      flex-direction: column;
      align-items: center;
      margin-top: 20px;
    }
    
    .get-caller-form input[type="text"],
    .get-caller-form input[type="tel"] {
      width: 80%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    
    .get-caller-form input[type="submit"] {
      width: 50%;
      padding: 10px;
      background-color: #007bff;
      color: #fff;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
    
    .get-caller-form input[type="submit"]:hover {
      background-color: #0056b3;
    }
    
    /* Styling for the EMI option */
    .emi-option {
      background-color: #f9f9f9;
      padding: 20px;
      border-radius: 5px;
      margin-top: 20px;
    }
    
    .emi-option h2 {
      font-size: 24px;
      text-align: center;
    }
    
    .emi-option__table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    
    .emi-option__table th,
    .emi-option__table td {
      border: 1px solid #ddd;
      padding: 8px;
      text-align: left;
    }
    
    .emi-option__table th {
      background-color: #f2f2f2;
    }
    
    .emi-option__table tr:nth-child(even) {
      background-color: #f9f9f9;
    }
    .warranty-safety {
      background-color: #f9f9f9;
      padding: 20px;
      border-radius: 5px;
      margin-top: 20px;
    }
    
    .warranty-safety__item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
    }
    
    .warranty-safety__icon {
      margin-right: 10px;
      font-size: 24px;
    }
    
    .warranty-safety__text {
      font-size: 18px;
    }
  </style>
</head>
<body>

<div class="car-images">
  <div>
    <img src="http://localhost/Jaguar/F-Type/jaguar-f-type-rear-view7.webp" alt="Description of the second image">
    <p style="color: black; font-size: 18px; font-family: 'Times New Roman', serif;">REAR</p>
  </div>
  <div>
    <img src="http://localhost/Jaguar/F-Type/jaguar-f-type-left-side-view8.webp" alt="Hyundai Creta Right Front Three Quarter">
    <p style="color: black; font-size: 20px; font-family: 'Arial Black', sans-serif;">LEFT</p>
  </div>
  <div>
    <img src="http://localhost/Jaguar/F-Type/jaguar-f-type-left-side-view1.webp" alt="Hyundai Creta Right Front Three Quarter">
    <p style="color: black; font-size: 18px; font-family: 'Times New Roman', serif;">LEFT</p>
  </div>
</div>

 
<h1 class="car-name">Jaguar F-Type</h1>
  
<div class="car-details">
  <div class="car-details-block">
    <h1>Price</h1>
    <p style="color: black; font-size: 18px; font-family: 'Times New Roman', serif;">₹ 1.00 - 1.56 crore</p>
  </div>
    
  <div class="car-details-block">
    <h1>Fuel</h1>
    <p style="color: black; font-size: 18px; font-family: 'Times New Roman', serif;">PETROL</p>
  </div>
    
  <div class="car-details-block">
    <h1>Milage</h1>
    <p style="color: black; font-size: 18px; font-family: 'Times New Roman', serif;">9.4 - 12.3 km/l</p>
  </div>
    
  <div class="car-details-block">
    <h1>Speed</h1>
    <p style="color: black; font-size: 18px; font-family: 'Times New Roman', serif;">180 kmph <i class="fas fa-tachometer-alt"></i></p>
  </div>
  
  <div class="warranty-safety">
  <div class="warranty-safety__item">
    <i class="fas fa-shield-alt warranty-safety__icon"></i>
    <span class="warranty-safety__text">Warranty: 3 Years or 100000 km</span>
  </div>
  <div class="warranty-safety__item">
    <i class="fas fa-star warranty-safety__icon"></i>
    <span class="warranty-safety__text">Safety Rating: 	Not Tested</span>
  </div>
</div>
</div>


<div class="emi-option">
  <h2>EMI Option</h2>
  <table class="emi-option__table">
    <tr>
      <th>Tenure (months)</th>
      <th>EMI Amount (per month)</th>
    </tr>
    <tr>
      <td>12</td>
      <td>Rs. 10,000</td>
    </tr>
    <tr>
      <td>24</td>
      <td>Rs. 5,500</td>
    </tr>
    <tr>
      <td>36</td>
      <td>Rs. 3,800</td>
    </tr>
  </table>
</div>
<div class="get-caller-option">
  <h2>Get a Caller from Dealer</h2>
  <form class="get-caller-form" action="#" method="post">
    <input type="text" name="name" placeholder="Your Name">
    <input type="tel" name="phone" placeholder="Your Phone Number" pattern="[0-9]{10}" title="Please enter a 10-digit phone number">

    <input type="submit" value="Request a Call">
  </form>
</div>


</body>
</html>
